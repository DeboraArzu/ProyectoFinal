﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MutiHilos_SO
{
    class Cola
    {
        public Registro root;
        public Registro tail;
        public int cantidad_registros;

        public Cola()
        {
            root = null;
            tail = null;
            cantidad_registros = 0;
        }

        public void push(Registro nuevo_registro)
        {
            if (tail == null)
            {
                //Si no hay nada en la pila
                tail = nuevo_registro;
                root = tail;
            }
            else
            {
                nuevo_registro.siguiente = root;
                root = nuevo_registro;
            }
            cantidad_registros++;
        }

        public Registro pop()
        {
            Registro registro_pop = new Registro();

            if (root == tail)
            {
                //si solo hay un registro en la pila
                registro_pop = root;
                root = null;
                tail = null;
            }
            else
            {
                root = root.siguiente;
                registro_pop = root;
            }
            cantidad_registros--;
            return registro_pop;
        }
    }
}
