﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MutiHilos_SO
{
    public partial class Proyecto_Final : Form
    {
        Cola cola;
        int numero_productores;
        int numero_consumidores;
        List<Hilo> poolthreads_productor;
        List<Hilo> poolthreads_consumidor;
        Queue<Productor> productores_en_espera;

        static Semaphore semaforo_p = new Semaphore(1, 1);
        static Semaphore semaforo_c = new Semaphore(1, 1);

        static Semaphore sp_aux = new Semaphore(1, 1); //Semaforo auxiliar productores
        static Semaphore sp_aux2 = new Semaphore(1, 1); //Semaforo auxiliar 2 productores
        static Semaphore semaforo_productor = new Semaphore(1, 1);

        static Semaphore sc_aux = new Semaphore(1, 1); //Semaforo auxiliar consumidores

        bool empezar_a_consumir = false;// Variable para el hilo productor
        bool empezar_a_consumir2 = false; // Variable para el hilo consumidor



        public Proyecto_Final()
        {
            InitializeComponent();
            cola = new Cola();
            numero_productores = 0;
            numero_consumidores = 0;
            poolthreads_productor = new List<Hilo>();
            poolthreads_consumidor = new List<Hilo>();
            productores_en_espera = new Queue<Productor>();

            //Semaphore semaforo_p = new Semaphore(1, 1);
            //Semaphore semaforo_c = new Semaphore(1, 1);
        }

        private void btnEmpezar_Click(object sender, EventArgs e)
        {
            numero_productores = Convert.ToInt32(nudProductores.Value);
            numero_consumidores = Convert.ToInt32(nudConsumidores.Value);
            gbInicio.Enabled = false;
            gbRegistros.Enabled = true;
            crearPoolThreads(numero_productores, numero_consumidores);
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            tablaProductores.Rows.Clear();
            tablaConsumidores.Rows.Clear();

            for(int i = 0; i < numero_productores; i++)
            {
                tablaProductores.Rows.Add("Thread" + poolthreads_productor[i].id + "(" + poolthreads_productor[i].origen +"-"+ poolthreads_productor[i].destino +")", poolthreads_productor[i].estado, poolthreads_productor[i].hechos + " de " + poolthreads_productor[i].por_hacer);
            }

            for (int i = 0; i < numero_consumidores; i++)
            {
                tablaConsumidores.Rows.Add("Thread" + poolthreads_consumidor[i].id + "(" + poolthreads_consumidor[i].origen + "-" + poolthreads_consumidor[i].destino + ")", poolthreads_consumidor[i].estado);
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            //Instruccion insert = true
            string origen = txtOrigen.Text;
            string destino = txtDestino.Text;
            int cantidad = Convert.ToInt32(nudCantidad.Value);
            crear_nuevo_productor(origen, destino, cantidad, true);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            //Instruccion delete = false
            string origen = txtOrigen.Text;
            string destino = txtDestino.Text;
            int cantidad = Convert.ToInt32(nudCantidad.Value);
            crear_nuevo_productor(origen, destino, cantidad, false);
        }

        public void crearPoolThreads(int _numero_productores, int _numero_consumidores)
        {
            for (int i = 0; i < _numero_productores; i++)
            {
                Hilo threadProductor = new Hilo(i, "Libre", ref productores_en_espera, ref cola, ref semaforo_p, ref sp_aux, ref semaforo_productor, ref sp_aux2, ref poolthreads_productor, ref poolthreads_consumidor, ref empezar_a_consumir);
                poolthreads_productor.Add(threadProductor);
            }
            for (int i = 0; i < _numero_consumidores; i++)
            {
                Hilo threadConsumidor = new Hilo(i, "Libre", ref cola, ref semaforo_c, ref sc_aux, ref poolthreads_consumidor, ref poolthreads_productor);
                poolthreads_consumidor.Add(threadConsumidor);
            }
        }

        public void crear_nuevo_productor(string _origen, string _destino, int _cantidad, bool _instruccion)
        {
            Productor nuevo_productor = new Productor(_origen, _destino, _cantidad, _instruccion);
            productores_en_espera.Enqueue(nuevo_productor);
            txtOrigen.Text = "";
            txtDestino.Text = "";
            nudCantidad.Value = 1;
        }

        private void Proyecto_Final_Load(object sender, EventArgs e)
        {

        }
    }
}
