﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MutiHilos_SO
{
    class Worker_Productor
    {
        public void producir(ref string _estado, ref Cola cola, ref int _hechos, ref int _por_hacer, ref string _destino, ref string _origen, ref Queue<Productor> en_espera, ref Semaphore s, ref Semaphore aux1, ref Semaphore semaforo, ref Semaphore s2, ref List<Hilo> productores, ref List<Hilo> consumidores, ref bool consumir)
        {
            consumir = false;
            while(true)
            {
                bool instruccion = false;
                _hechos = 0;
                _por_hacer = 0;
                _origen = "";
                _destino = "";

                aux1.WaitOne();
                if (en_espera.Count > 0)
                {
                    Productor p = en_espera.Dequeue();
                    _por_hacer = p.cantidad;
                    _origen = p.origen;
                    _destino = p.destino;
                    instruccion = p.instruccion;
                }
                aux1.Release();

                while (_hechos != _por_hacer)
                {
                    _estado = "Procesando";
                    Registro nuevo_registro = new Registro(_origen, _destino, instruccion);
                    //_hechos++;
                    //Inicio Region critica............
                    s.WaitOne();
                    semaforo.WaitOne();
                    cola.push(nuevo_registro);
                    _hechos++;
                    Thread.Sleep(1);
                    if (cola.cantidad_registros == 10)
                    {
                        //Dormir a los que estan procesando
                        for (int i = 0; i < productores.Count; i++)
                        {
                            if (productores[i].estado == "Procesando")
                            {
                                //if (productores[i].hechos == productores[i].por_hacer)
                                //{
                                //    productores[i].estado = "Libre";
                                //}
                                //else
                                //{
                                //    productores[i].estado = "Dormido";
                                //}
                                productores[i].estado = "Dormido";
                            }
                        }
                        consumir = true; //Ya se durmieron los productores ahora hay que consumir
                        while (_estado == "Dormido" || _estado == "Libre")
                        {
                            //s2.WaitOne();
                            //No se sale hasta que la cola este vacia de nuevo
                            if (cola.cantidad_registros == 0)
                            {
                                //Despertar a los que estaban dormidos
                                for (int i = 0; i < productores.Count; i++)
                                {
                                    if (productores[i].estado == "Dormido")
                                    {
                                        productores[i].estado = "Procesando";
                                    }
                                }
                            }
                            //s2.Release();
                        }
                    }
                    semaforo.Release();
                    s.Release();
                }
                _estado = "Libre";
                //Fin Region critica...............


                //        while (_por_hacer == 0)
                //        {
                //            s.WaitOne();
                //            bool esperar = false;
                //            for(int i  = 0; i < productores.Count; i++)
                //            {
                //                if(productores[i].estado == "Dormido")
                //                {
                //                    esperar = true;
                //                    i = productores.Count;
                //                }
                //            }
                //            //Inicio region critica
                //            if (en_espera.Count > 0 && !esperar)
                //            {
                //                Productor p = en_espera.Dequeue();
                //                _por_hacer = p.cantidad;
                //                _origen = p.origen;
                //                _destino = p.destino;
                //                instruccion = p.instruccion;
                //            }
                //            //fin region critica
                //            s.Release();
                //        }
                //        while (_hechos != _por_hacer)
                //        {
                //            aux1.WaitOne();
                //            if(cola.cantidad_registros >= 10)
                //            {
                //                _estado = "Dormido";
                //            }
                //            aux1.Release();

                //            while (_estado == "Dormido")
                //            {
                //                s2.WaitOne();
                //                bool producir = true;
                //                for (int i = 0; i < consumidores.Count; i++)
                //                {
                //                    if (consumidores[i].estado != "Dormido") //si alguno no esta dormido no hay que producir
                //                    {
                //                        producir = false;
                //                        i = consumidores.Count;
                //                    }
                //                }
                //                if (cola.cantidad_registros == 0 && producir)
                //                {
                //                    for (int i = 0; i < productores.Count; i++)
                //                    {
                //                        if (productores[i].estado == "Dormido")
                //                        {
                //                            _estado = "Procesando";
                //                        }
                //                    }
                //                }
                //                else
                //                {
                //                    int h = 0;
                //                }
                //                s2.Release();
                //            }

                //            _estado = "Procesando";
                //            Registro nuevo_registro = new Registro(_origen,_destino,instruccion);
                //            //Inicio Region critica............
                //            semaforo.WaitOne();
                //            cola.push(nuevo_registro);
                //            _hechos++;
                //            Thread.Sleep(1000);
                //            semaforo.Release();
                //            //Fin Region critica...............
                //        }
                //        _estado = "Libre";
            }
        }
    }
}
