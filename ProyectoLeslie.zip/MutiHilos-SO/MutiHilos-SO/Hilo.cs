﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MutiHilos_SO
{
    class Hilo
    {
        public int id;
        public string origen;
        public string destino;
        public string estado;
        Thread thread;
        public int hechos;
        public int por_hacer;

        public Hilo()
        {
            //id = 0;
            //estado = "Libre";
            //thread = null;
            //hechos = 0;
            //por_hacer = 0;
        }

        //Hilo Productor
        public Hilo(int _id, string _estado, ref Queue<Productor> en_espera, ref Cola _cola, ref Semaphore semaforo, ref Semaphore semaforo_aux, ref Semaphore semaforo_productor, ref Semaphore semaforo2, ref List<Hilo> productores, ref List<Hilo> consumidores, ref bool consumir)
        {
            id = _id;
            estado = _estado;
            Cola c = _cola;
            Queue<Productor> waiting_list = en_espera;
            Worker_Productor wp = new Worker_Productor();
            Semaphore s = semaforo;
            Semaphore s2 = semaforo2;
            Semaphore s_aux = semaforo_aux;
            Semaphore semaforo_producir = semaforo_productor;
            List<Hilo> producers = productores;
            List<Hilo> consumers = consumidores;
            bool _consumir = consumir;

            thread = new Thread(() => wp.producir(ref estado, ref c, ref hechos, ref por_hacer, ref destino, ref origen, ref waiting_list, ref s, ref s_aux, ref semaforo_producir, ref s2, ref producers, ref consumers, ref _consumir));
            thread.Start();
        }

        //Hilo Consumidor
        public Hilo(int _id, string _estado, ref Cola _cola, ref Semaphore semaforo, ref Semaphore semaforo_aux, ref List<Hilo> consumidores, ref List<Hilo> productores)
        {
            id = _id;
            estado = _estado;
            Cola c = _cola;
            Worker_Consumidor wc = new Worker_Consumidor();
            Semaphore s = semaforo;
            Semaphore s_aux = semaforo_aux;
            List<Hilo> consumer = consumidores;
            List<Hilo> producer = productores;

            thread = new Thread(() => wc.consumir(ref estado, ref origen, ref destino, ref c, ref s, ref s_aux, ref consumer, ref producer));
            thread.Start();
        }



    }
}
