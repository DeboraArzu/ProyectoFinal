﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MutiHilos_SO
{
    class Registro
    {
        public string origen;
        public string destino;
        public bool instruccion; //False = delete, True = insert
        public Registro siguiente;

        public Registro()
        {
            origen = "";
            destino = "";
            instruccion = true; //por default se pone instruccion de insert
            siguiente = null;
        }

        public Registro(string _origen, string _destino, bool _instruccion)
        {
            origen = _origen;
            destino = _destino;
            instruccion = _instruccion;
            siguiente = null;
        }
    }
}
