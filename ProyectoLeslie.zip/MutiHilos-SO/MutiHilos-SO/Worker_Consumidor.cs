﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Threading;

namespace MutiHilos_SO
{
    class Worker_Consumidor
    {
        MySqlConnection connection = null;

        public void conectar()
        {
            
            string connectionString;
            connectionString = "server=127.0.0.1;user id=sa;password=annabelliqua;database=sys";
            connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();
            }
            catch (MySqlException ex)
            {
                int h = 0;
            }
        }

        public void consumir(ref string _estado, ref string _origen, ref string _destino, ref Cola _cola, ref Semaphore semaforo, ref Semaphore s_aux, ref List<Hilo> consumidores, ref List<Hilo> productores)
        {
            //bool consumir = false;
            _estado = "Libre";
            bool _consumir = false;
            bool esta_llena = false;
            bool instruccion = false;
            while (true)
            {
                _origen = "";
                _destino = "";
                semaforo.WaitOne();
                s_aux.WaitOne();
                //Revisar si hay dormidos
                _consumir = false;
                esta_llena = false;
                for(int i = 0; i < productores.Count; i++)
                {
                    if(productores[i].estado == "Dormido")
                    {
                        _consumir = true;
                    }
                }
                if((_cola.cantidad_registros > 0) && _consumir== true)
                {
                    esta_llena = true;
                }
                if(_consumir == true && esta_llena == true)
                {
                    //Si ya se puede consumir
                    _estado = "Procesando";
                    Registro registro_extraido = _cola.pop();
                    _origen = registro_extraido.origen;
                    _destino = registro_extraido.destino;
                    instruccion = registro_extraido.instruccion;
                    Console.WriteLine(_cola.cantidad_registros);
                    if(instruccion == true)
                    {
                        insert(_origen, _destino);
                    }
                    else
                    {
                        delete(_origen, _destino);
                    }
                    Thread.Sleep(3000);
                    if(_cola.cantidad_registros == 0)
                    {
                        _consumir = false;
                    }
                }
                s_aux.Release();
                semaforo.Release();
                _estado = "Libre";


                //while (_estado == "Dormido")
                //{
                //    s_aux.WaitOne();
                //    for (int i = 0; i < productores.Count; i++)
                //    {
                //        if(productores[i].estado == "Procesando")
                //        {
                //            consumir = false;
                //            i = productores.Count;
                //        }
                //        else
                //        {
                //            consumir = true;
                //        }
                //    }
                //    if (_cola.cantidad_registros == 10 && consumir)
                //    {
                //        for (int i = 0; i < consumidores.Count; i++)
                //        { 
                //            if(consumidores[i].estado == "Dormido")
                //            {
                //                _estado = "Procesando";
                //            }
                //        }
                //    }
                //    else
                //    {
                //        _estado = "Dormido";
                //    }
                //    s_aux.Release();
                //}
                //consumir = false;
                ////Inicia region critica
                //semaforo.WaitOne();
                //if (_cola.cantidad_registros != 0)
                //{
                //    _estado = "Procesando";
                //    Registro registro_extraido = _cola.pop();
                //    _origen = registro_extraido.origen;
                //    _destino = registro_extraido.destino;
                //    Console.WriteLine(_cola.cantidad_registros);
                //    Thread.Sleep(1000);
                //}
                //else
                //{
                //    _estado = "Dormido";
                //    for(int i = 0; i < consumidores.Count; i++)
                //    {
                //        consumidores[i].estado = "Dormido";
                //    }
                //}
                //semaforo.Release();
                //_origen = "";
                //_destino = "";
                ////Fin region critica
            }
        }

        public void insert(string _origen, string _destino)
        {
            conectar();
            string query = "Insert into lista_transaccion(origen,destino) values('" + _origen + "','" + _destino + "');";
            MySqlCommand MyCommand2 = new MySqlCommand(query, connection);
            MySqlDataReader MyReader2;
            MyReader2 = MyCommand2.ExecuteReader();
            connection.Close();
        }

        public void delete(string _origen, string _destino)
        {
            conectar();
            string query = "delete from lista_transaccion where origen='" + _origen + "' and destino = '" + _destino + "';";
            MySqlCommand MyCommand2 = new MySqlCommand(query, connection);
            MySqlDataReader MyReader2;
            MyReader2 = MyCommand2.ExecuteReader();
            connection.Close();
        }
    }
}
