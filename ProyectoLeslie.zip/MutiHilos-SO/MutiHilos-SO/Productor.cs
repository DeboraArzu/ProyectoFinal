﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MutiHilos_SO
{
    class Productor
    {
        public string origen;
        public string destino;
        public int cantidad;
        public bool instruccion;

        public Productor()
        {
            origen = "";
            destino = "";
            cantidad = 0;
            instruccion = false;
        }

        public Productor(string _origen, string _destino, int _cantidad, bool _instruccion)
        {
            origen = _origen;
            destino = _destino;
            cantidad = _cantidad;
            instruccion = _instruccion;
        }
    }
}
